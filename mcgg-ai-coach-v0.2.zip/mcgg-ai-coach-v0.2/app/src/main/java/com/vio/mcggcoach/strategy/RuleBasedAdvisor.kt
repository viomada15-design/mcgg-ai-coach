package com.vio.mcggcoach.strategy

import com.vio.mcggcoach.model.GameState

data class Advice(val headline: String, val reason: String, val confidence: Double)

class RuleBasedAdvisor {
    fun advise(s: GameState): Advice {
        val gold = s.gold ?: 0
        val hp = s.hp ?: 100

        if (hp <= 25) {
            return Advice(
                "STABILIZE NOW",
                "Low HP raises elimination risk. Spend only toward immediate board strength, a key star upgrade, frontline, or synergy breakpoint.",
                0.78
            )
        }

        if (gold >= 40 && hp >= 45) {
            return Advice(
                "HOLD GOLD / AVOID PANIC REROLL",
                "Economy is healthy and HP is not yet critical. Preserve flexibility until a clear upgrade, level breakpoint, or Commander-skill timing appears.",
                0.72
            )
        }

        if (s.commander.skillReady == true) {
            return Advice(
                "CHECK COMMANDER SKILL TIMING",
                "Commander skill is available. Compare its immediate power/economy value against rerolling or leveling before spending gold.",
                0.67
            )
        }

        return Advice(
            "OBSERVE NEXT SHOP + OPPONENT",
            "Not enough high-confidence signals yet. Keep options open and scout before committing resources.",
            0.58
        )
    }
}
