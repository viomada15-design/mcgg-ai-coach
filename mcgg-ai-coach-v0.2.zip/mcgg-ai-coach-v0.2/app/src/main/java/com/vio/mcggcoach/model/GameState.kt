package com.vio.mcggcoach.model

data class CommanderState(
    val name: String? = null,
    val skillName: String? = null,
    val skillLevel: Int? = null,
    val skillReady: Boolean? = null,
    val stacks: Int? = null
)

data class GameState(
    val phase: String = "unknown",
    val round: String? = null,
    val hp: Int? = null,
    val gold: Int? = null,
    val level: Int? = null,
    val boardSlotsUsed: Int? = null,
    val boardSlotsMax: Int? = null,
    val commander: CommanderState = CommanderState(),
    val synergies: Map<String, Int> = emptyMap(),
    val shopHeroes: List<String> = emptyList(),
    val benchHeroes: List<String> = emptyList(),
    val items: List<String> = emptyList(),
    val goGoCards: List<String> = emptyList(),
    val notes: List<String> = emptyList()
)
