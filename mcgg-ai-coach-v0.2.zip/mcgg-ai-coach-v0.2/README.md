# MCGG AI Coach

Android MVP for a screen-observing, non-automating Magic Chess: Go Go strategy overlay.

## Current scope
- overlay permission + floating coach
- MediaProjection permission flow
- structured GameState including Commander skill state
- rule-based advisor seed
- patch-aware knowledge asset placeholder
- GitHub Actions debug APK build

## Not included yet
- automatic OCR/object recognition
- live frame sampling/change detection
- complete Season 7 Commander/hero/item/Go Go Card database
- probabilistic top-4/win prediction

The coach provides recommendations only; it does not tap, inject into, or modify the game.
